﻿using System.ComponentModel.DataAnnotations;

namespace cad_cliente_final.Models
{
    public class Dados
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Nome")]
        public required string Nome { get; set; }

        [Required]
        [Display(Name = "Email")]
        public required string Email { get; set; }

        [Required]
        public required string Rua { get; set; }

        [Required]
        public int Numero { get; set; }

        [Required]
        public required string Cidade { get; set; }

        [Required]
        public required string Estado { get; set; }

        [Required]
        public required string Pais { get; set; }
    }
}
