﻿using cad_cliente_final.Models;
using Microsoft.EntityFrameworkCore;

namespace cad_cliente_final.Context
{
    public class AppCont : DbContext
    {

            public AppCont(DbContextOptions<AppCont> options) : base(options)
            {

            }

            public DbSet<Dados> InfoClientes { get; set; }

        }
    }
