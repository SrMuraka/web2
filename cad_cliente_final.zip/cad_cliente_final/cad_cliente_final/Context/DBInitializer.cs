﻿using cad_cliente_final.Models;

namespace cad_cliente_final.Context
{
    public static class DBInitializer
    {
        public static void Seed(WebApplication app)
        {
            using (var serviceScope = app.Services.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<AppCont>();

                context.Database.EnsureCreated();

                // Verifica se já existem clientes no banco
                if (!context.InfoClientes.Any())
                {
                    // Adiciona uma lista de clientes e seus endereços
                    context.InfoClientes.AddRange(new List<Dados>
                    {
                        new Dados
                        {
                            Nome = "Cleiton",
                            Email = "cleitin@gmail.com",
                            Rua = "Avenida Principal",
                            Numero = 123,
                            Cidade = "São Paulo",
                            Estado = "SP",
                            Pais = "Brasil"
},

                        new Dados
                        {
                            Nome = "Ana Souza",
                            Email = "ana.souza@gmail.com",
                            Rua = "Rua das Flores",
                            Numero = 456,
                            Cidade = "Rio de Janeiro",
                            Estado = "RJ",
                            Pais = "Brasil"
                        },

                        new Dados
                        {
                            Nome = "Bruno Lima",
                            Email = "bruno.lima@gmail.com",
                            Rua = "Travessa Boa Vista",
                            Numero = 789,
                            Cidade = "Belo Horizonte",
                            Estado = "MG",
                            Pais = "Brasil"
                        },

                        new Dados
                        {
                            Nome = "Camila Ferreira",
                            Email = "camila.ferreira@gmail.com",
                            Rua = "Rua do Comércio",
                            Numero = 321,
                            Cidade = "Curitiba",
                            Estado = "PR",
                            Pais = "Brasil"
                        },

                        new Dados
                        {
                            Nome = "Diego Santos",
                            Email = "diego.santos@gmail.com",
                            Rua = "Avenida dos Pioneiros",
                            Numero = 654,
                            Cidade = "Fortaleza",
                            Estado = "CE",
                            Pais = "Brasil"
                        }
                    });

                    // Salva as mudanças no banco de dados
                    context.SaveChanges();
                }
            }
        }
    }
}

