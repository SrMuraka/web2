using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Trab2.Context;
using Trab2.Models;

namespace Trab2.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _dbContext;

        public HomeController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            var allClients = _dbContext.ClientRecords.ToList();
            return View(allClients);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var client = await _dbContext.ClientRecords
                .FirstOrDefaultAsync(x => x.ID == id);

            if (client == null)
            {
                return BadRequest();
            }

            return View(client);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ClientRecord client, IFormFile photo)
        {
            if (photo != null && photo.Length > 0)
            {
                using var memoryStream = new MemoryStream();
                photo.CopyTo(memoryStream);
                client.Photo = memoryStream.ToArray();
            }

            _dbContext.ClientRecords.Add(client);
            _dbContext.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int? id)
        {
            if (id == null || !_dbContext.ClientRecords.Any(c => c.ID == id))
            {
                return NotFound();
            }

            var client = _dbContext.ClientRecords.Find(id);
            return View(client);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, ClientRecord client, IFormFile photo)
        {
            if (id != client.ID)
            {
                return NotFound();
            }

            try
            {
                if (photo != null && photo.Length > 0)
                {
                    using var memoryStream = new MemoryStream();
                    photo.CopyTo(memoryStream);
                    client.Photo = memoryStream.ToArray();
                }
                else
                {
                    client.Photo = _dbContext.ClientRecords.AsNoTracking()
                        .FirstOrDefault(c => c.ID == client.ID)?.Photo;
                }

                _dbContext.Update(client);
                _dbContext.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_dbContext.ClientRecords.Any(e => e.ID == client.ID))
                {
                    return NotFound();
                }
                throw;
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var client = _dbContext.ClientRecords
                .FirstOrDefault(m => m.ID == id);

            if (client == null)
            {
                return NotFound();
            }

            return View(client);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var client = _dbContext.ClientRecords.Find(id);

            if (client == null)
            {
                return NotFound();
            }

            _dbContext.ClientRecords.Remove(client);
            _dbContext.SaveChanges();

            return RedirectToAction(nameof(Index));
        }
    }
}
