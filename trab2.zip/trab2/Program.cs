using Microsoft.EntityFrameworkCore;
using Trab2.Context;

var builder = WebApplication.CreateBuilder(args);

// Configura��o do DbContext para usar o SQL Server
builder.Services.AddDbInitializer<AppCont>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("Trabalho2"));
});

// Adicionando servi�os para MVC
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configura��o do pipeline de requisi��es
if (!app.Environment.IsDevelopment())
{
    // Em produ��o, usa tratamento de exce��o e HSTS
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    // Em desenvolvimento, habilita a exibi��o de erros detalhados
    app.UseDeveloperExceptionPage();
}

// Inicializa o banco de dados com dados padr�o, se necess�rio
AppDBInitializer.Seed(app);

app.UseHttpsRedirection();

// Habilita a manipula��o de arquivos est�ticos (CSS, JS, imagens, etc.)
app.UseStaticFiles();

// Configura��o de roteamento
app.UseRouting();

app.UseAuthorization();

// Mapeia as rotas dos controladores
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Cadastro}/{action=Index}/{id?}");

app.Run();
