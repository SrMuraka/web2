﻿using System;
using Trab2.Models;

namespace Trab2.Context
{
    public class DatabaseInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppDbInitializer>();

                if (context == null) throw new Exception("Database context not found");

                // Garantir que o banco de dados está criado
                context.Database.EnsureCreated();

                // Inserir dados apenas se a tabela estiver vazia
                if (!context.ClientRecords.Any())
                {
                    string basePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");

                    // Método auxiliar para carregar imagens
                    byte[] LoadImage(string fileName)
                    {
                        string filePath = Path.Combine(basePath, fileName);
                        if (File.Exists(filePath))
                        {
                            return File.ReadAllBytes(filePath);
                        }
                        throw new FileNotFoundException($"File not found: {filePath}");
                    }

                    // Carregamento das imagens
                    byte[] photo1 = LoadImage("photo1.jpg");
                    byte[] photo2 = LoadImage("photo2.jpg");
                    byte[] photo3 = LoadImage("photo3.jpg");

                    // Adicionando registros
                    var clientRecords = new List<ClientRecord>
                    {
                        new ClientRecord
                        {
                            Name = "John Doe",
                            CPF = "123.456.789-78",
                            Email = "john.doe@example.com",
                            BirthDate = new DateTime(2000, 11, 07),
                            Gender = "Not Specified",
                            Photo = photo2,
                            Address = "Flower Street",
                            AddressNumber = "123",
                            AdditionalInfo = "Apt 101",
                            Neighborhood = "Downtown",
                            City = "São Paulo",
                            State = "SP",
                            PostalCode = "01000-000"
                       
                        },
                        new ClientRecord
                        {
                            Name = "Alex Johnson",
                            CPF = "412.456.654-78",
                            Email = "alex.johnson@example.com",
                            BirthDate = new DateTime(2005, 08, 11),
                            Gender = "Male",
                            Photo = photo3,
                            Address = "Palm Street",
                            AddressNumber = "87",
                            AdditionalInfo = "Apt 12",
                            Neighborhood = "Downtown",
                            City = "São Paulo",
                            State = "SP",
                            PostalCode = "01000-242"
                        }
                    };

                    context.ClientRecords.AddRange(clientRecords);
                    context.SaveChanges();
                }
            }
        }
    }
}
