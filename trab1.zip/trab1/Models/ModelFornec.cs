﻿using System.ComponentModel.DataAnnotations;

namespace trab1.Models
{
    public class Fornecedor
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Por favor, insira a Razão Social.")]
        public string RazaoSocial { get; set; }

        [Required(ErrorMessage = "Por favor, insira o Nome Fantasia.")]
        public string NomeFantasia { get; set; }

        [Required(ErrorMessage = "Por favor, insira um email válido.")]
        [EmailAddress(ErrorMessage = "Por favor, insira um email válido.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Por favor, insira o telefone.")]
        [Phone(ErrorMessage = "Por favor, insira um telefone válido.")]
        public string Telefone { get; set; }

        public string NomePessoaContato { get; set; }

        [Required(ErrorMessage = "Por favor, insira o tipo de logradouro.")]
        public string TipoLogradouro { get; set; }

        [Required(ErrorMessage = "Por favor, insira o nome do logradouro.")]
        public string NomeLogradouro { get; set; }

        [Required(ErrorMessage = "Por favor, insira o número.")]
        public string Numero { get; set; }

        public string Complemento { get; set; }

        [Required(ErrorMessage = "Por favor, insira o bairro.")]
        public string Bairro { get; set; }

        [Required(ErrorMessage = "Por favor, insira o CEP no formato 12345-678.")]
        [RegularExpression(@"\d{5}-\d{3}", ErrorMessage = "Por favor, insira o CEP no formato 12345-678.")]
        public string CEP { get; set; }

        [Required(ErrorMessage = "Por favor, insira a cidade.")]
        public string Cidade { get; set; }

        [Required(ErrorMessage = "Por favor, insira o estado.")]
        public string Estado { get; set; }
    }
}
