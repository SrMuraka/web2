using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using trab1.Data;
using trab1.Models;

namespace trab1.Controllers
{
    public class HomeController : Controller
    {
        private readonly BancoContext _context;

        public HomeController(BancoContext context)
        {
            _context = context;
        }

        // Lista todos os fornecedores
        public async Task<IActionResult> Index()
        {
            var fornecedores = await _context.Fornecedores.ToListAsync();
            return View(fornecedores);
        }

        // Exibe a view para criar um novo fornecedor
        public IActionResult Criar() => View();

        // Cria um novo fornecedor
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Criar([Bind("Id,RazaoSocial,NomeFantasia,Email,Telefone,NomePessoaContato,TipoLogradouro,NomeLogradouro,Numero,Complemento,Bairro,CEP,Cidade,Estado")] Fornecedor fornecedor)
        {
            if (!ModelState.IsValid)
            {
                return View(fornecedor);
            }

            _context.Add(fornecedor);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // Exibe a view para editar um fornecedor
        public async Task<IActionResult> Editar(int? id)
        {
            if (!id.HasValue)
            {
                return NotFound();
            }

            var fornecedor = await _context.Fornecedores.FindAsync(id);
            if (fornecedor == null)
            {
                return NotFound();
            }

            return View(fornecedor);
        }

        // Atualiza os dados de um fornecedor
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(int id, [Bind("Id,RazaoSocial,NomeFantasia,Email,Telefone,NomePessoaContato,TipoLogradouro,NomeLogradouro,Numero,Complemento,Bairro,CEP,Cidade,Estado")] Fornecedor fornecedor)
        {
            if (id != fornecedor.Id)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(fornecedor);
            }

            try
            {
                _context.Update(fornecedor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FornecedorExists(fornecedor.Id))
                {
                    return NotFound();
                }

                throw;
            }
        }

        // Exibe os detalhes de um fornecedor
        public async Task<IActionResult> Delete(int? id)
        {
            if (!id.HasValue)
            {
                return NotFound();
            }

            var fornecedor = await _context.Fornecedores.FirstOrDefaultAsync(m => m.Id == id);
            if (fornecedor == null)
            {
                return NotFound();
            }

            return View(fornecedor);
        }

        // Exclui um fornecedor
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var fornecedor = await _context.Fornecedores.FindAsync(id);
            if (fornecedor == null)
            {
                return NotFound();
            }

            try
            {
                _context.Fornecedores.Remove(fornecedor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                ModelState.AddModelError("", "Erro ao excluir o fornecedor.");
                return View(fornecedor);
            }
        }

        // Retorna detalhes de um fornecedor no formato JSON
        [HttpGet]
        public async Task<IActionResult> DetalhesJson(int id)
        {
            var fornecedor = await _context.Fornecedores.FirstOrDefaultAsync(m => m.Id == id);
            if (fornecedor == null)
            {
                return NotFound();
            }

            return Json(new
            {
                razaoSocial = fornecedor.RazaoSocial,
                nomeFantasia = fornecedor.NomeFantasia,
                email = fornecedor.Email,
                telefone = fornecedor.Telefone,
                nomePessoaContato = fornecedor.NomePessoaContato,
                tipoLogradouro = fornecedor.TipoLogradouro,
                nomeLogradouro = fornecedor.NomeLogradouro,
                numero = fornecedor.Numero,
                complemento = fornecedor.Complemento,
                bairro = fornecedor.Bairro,
                cep = fornecedor.CEP,
                cidade = fornecedor.Cidade,
                estado = fornecedor.Estado


            });
        }

        // Verifica se um fornecedor existe
        private bool FornecedorExists(int id)
        {
            return _context.Fornecedores.Any(e => e.Id == id);
        }
    }
}
